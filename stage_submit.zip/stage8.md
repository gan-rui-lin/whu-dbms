前置题目：题目七（order by操作符）

题目种类：基础功能

推荐知识点：基本算子实现

题目描述：

本题目要求各学生实现块嵌套循环连接算法（Block Nested-Loop-Join）。 

 

提示：

（1）功能题目对代码框架没有限制，学生可以修改、增添、删除数据结构及接口，也可以对框架进行重构。

（2）本题目的测试点为SQL测试，测试数据中涉及到的表数据大小超过了内存大小，学生可以自己定义join_buffer的大小。

（3）测试数据中包含非等值连接，不包含索引，join的表中不包含同名字段。

（4）在本题目中，测试平台提供2GB内存，学生设置的buffer大小不应该超过内存限制。

 

测试示例：

select * from t1, t2 where t1.id = t2.t_id order by t1.id;

select * from t1, t2 where t1.id < t2.t_id and t2.t_id < 1000;

 

测试输出要求：

本题目的输出要求写入数据库文件夹下的output.txt文件中，例如测试数据库名称为BNLJ_test_db，则在测试时使用./bin/rmdb BNLJ_test_db命令来启动服务端，对应输出应写入buid/BNLJ_test_db/output.txt文件中。