前置题目：题目一（存储管理）

题目种类：基础功能

推荐知识点：逻辑查询优化、查询解析、基本算子实现、查询执行框架、元数据存储组织

题目描述：

在实现题目一功能的基础上增加查询执行模块，使得系统支持通过测试需要的元数据管理、DDL语句、DQL语句、DML语句。

提示：

l 本题目提供了空缺的样例代码，学生可以选择进行补全，也可以选择自行构建。如果选择补全空缺的样例代码，需要实现“元数据管理与DDL语句”和“DQL语句和DML语句”。

l 本题目通过sql进行测试，分为五个测试点，它们依次是“尝试建表”、“单表插入与条件查询”、“单表更新与条件查询”、“单表删除与条件查询”、“连接查询”。

l 对于所有不合法的sql语句，都需要输出failure。（包括语法错误、删除不存在的表、创建已经存在的表、where条件中出现不存在的字段等）

l 注意浮点数的精度问题，在最后一个测试点basic_query_test5中涉及到了浮点数精度的测试。（每个测试点的测试知识点参考测试说明文档）



 

1、元数据管理与DDL语句

本任务要求学生对数据库的元数据进行管理，并实现基本的DDL语句，包括create table和drop table两种语句。课程提供的框架中，与元数据管理和DDL语句相关的代码文件位于src/system文件夹下，代码框架中提供了create table语句的实现方式，学生需要补充完善sm_manager.cpp文件中未实现的函数（index相关的函数除外）。

 

2、DQL语句和DML语句

 

DML语句要求实现基本的增删改，即insert、delete、update语句。DQL语句要求实现select语句。在完成本任务之前，学生需要首先阅读项目结构文档中查询解析、查询优化、查询执行的相关说明，以及代码框架中src/analyze、src/optimizer、src/execution文件夹下的代码文件，学生需要实现代码框架中未提供的功能，包括语义检查、查询执行计划的生成、执行算子等。语义检查包括但不限于创建已有的表、删除不存在的表等。

在课程提供的框架中，analyze模块提供了insert、select、delete语句的相关代码，把parser生成的抽象语法树转化成了查询计划生成所需要的Query列表，并进行了部分语义检查，学生需要补充完善update语句的相关代码。optimizer模块提供了查询计划的生成，但并未对查询计划进行逻辑优化和物理优化。execution模块中提供了insert算子的完整实现，学生需要实现扫描算子、连接算子、投影算子、update算子和delete算子。

 

本题目通过SQL来进行测试，因此学生可以对代码进行重构。

 

测试示例：

 

测试点1: 尝试建表（2分）

测试示例：

create table t1(id int,name char(4));

show tables;

create table t2(id int);

show tables;

drop table t1;

show tables;

drop table t2;

show tables;

期待输出：

| Tables |

| t1 |

| Tables |

| t1 |

| t2 |

| Tables |

| t2 |

| Tables |

 

测试点2: 单表插入与条件查询（2分）

测试示例：

create table grade (name char(4),id int,score float);

insert into grade values ('Data', 1, 90.5);

insert into grade values ('Data', 2, 95.0);

insert into grade values ('Calc', 2, 92.0);

insert into grade values ('Calc', 1, 88.5);

select * from grade;

select score,name,id from grade where score > 90;

select id from grade where name = 'Data';

select name from grade where id = 2 and score > 90;  

期待输出：

| name | id | score |

| Data | 1 | 90.500000 |

| Data | 2 | 95.000000 |

| Calc | 2 | 92.000000 |

| Calc | 1 | 88.500000 |

| score | name | id |

| 90.500000 | Data | 1 |

| 95.000000 | Data | 2 |

| 92.000000 | Calc | 2 |

| id |

| 1 |

| 2 |

| name |

| Data |

| Calc |

 

测试点3：单表更新与条件查询（2分）

测试示例：

create table grade (name char(4),id int,score float);

insert into grade values ('Data', 1, 90.5);

insert into grade values ('Data', 2, 95.0);

insert into grade values ('Calc', 2, 92.0);

insert into grade values ('Calc', 1, 88.5);

select * from grade;

update grade set score = 99.0 where name = 'Calc' ;

select * from grade;

update grade set name = 'test' where name > 'A';

select * from grade;

update grade set name = 'test' ,id = -1,score = 0 where name = 'test' and score > 90;

select * from grade;

期待输出：

| name | id | score |

| Data | 1 | 90.500000 |

| Data | 2 | 95.000000 |

| Calc | 2 | 92.000000 |

| Calc | 1 | 88.500000 |

| name | id | score |

| Data | 1 | 90.500000 |

| Data | 2 | 95.000000 |

| Calc | 2 | 99.000000 |

| Calc | 1 | 99.000000 |

| name | id | score |

| test | 1 | 90.500000 |

| test | 2 | 95.000000 |

| test | 2 | 99.000000 |

| test | 1 | 99.000000 |

| name | id | score |

| test | -1 | 0.000000 |

| test | -1 | 0.000000 |

| test | -1 | 0.000000 |

| test | -1 | 0.000000 |

 

测试点4：单表删除与条件查询（2分）

测试示例：

create table grade (name char(4),id int,score float);

insert into grade values ('Data', 1, 90.5);

select * from grade;

delete from grade where score > 90;

select * from grade;

期待输出：

| name | id | score|

| Data | 1 | 90.500000 |

| name | id | score|

 

测试点5：连接查询（4分）

create table t ( id int , t_name char (3));

create table d (d_name char(5),id int);

insert into t values (1,'aaa');

insert into t values (2,'baa');

insert into t values (3,'bba');

insert into d values ('12345',1);

insert into d values ('23456',2);

select * from t, d;

select t.id,t_name,d_name from t,d where t.id = d.id;

期待输出：

| id | t_name | d_name | id |

| 1 | aaa | 23456 | 2 |

| 1 | aaa | 12345 | 1 |

| 2 | baa | 23456 | 2 |

| 2 | baa | 12345 | 1 |

| 3 | bba | 23456 | 2 |

| 3 | bba | 12345 | 1 |

| id | t_name | d_name |

| 1 | aaa | 12345 |

| 2 | baa | 23456 |

 

测试输出要求：

本题目的输出要求写入数据库文件夹下的output.txt文件中，例如测试数据库名称为execution_test_db，则在测试时使用./bin/rmdb execution_test_db命令来启动服务端，对应输出应写入buid/execution_test_db/output.txt文件中。

